/*
 * GStreamer
 * Copyright (C) 2012 Matthew Waters <ystree00@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 */

#ifndef __GST_GL_COLOR_CONVERT_H__
#define __GST_GL_COLOR_CONVERT_H__

#include <gst/video/video.h>
#include <gst/gstmemory.h>

#include <gst/gl/gstgl_fwd.h>

G_BEGIN_DECLS

GST_GL_API
GType gst_gl_color_convert_get_type (void);
#define GST_TYPE_GL_COLOR_CONVERT (gst_gl_color_convert_get_type())
#define GST_GL_COLOR_CONVERT(obj) (G_TYPE_CHECK_INSTANCE_CAST((obj),GST_TYPE_GL_COLOR_CONVERT,GstGLColorConvert))
#define GST_GL_COLOR_CONVERT_CLASS(klass) (G_TYPE_CHECK_CLASS_CAST((klass),GST_TYPE_GL_DISPLAY,GstGLColorConvertClass))
#define GST_IS_GL_COLOR_CONVERT(obj) (G_TYPE_CHECK_INSTANCE_TYPE((obj),GST_TYPE_GL_COLOR_CONVERT))
#define GST_IS_GL_COLOR_CONVERT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass),GST_TYPE_GL_COLOR_CONVERT))
#define GST_GL_COLOR_CONVERT_CAST(obj) ((GstGLColorConvert*)(obj))

/**
 * GstGLColorConvert
 *
 * Opaque #GstGLColorConvert object
 */
struct _GstGLColorConvert
{
  /*< private >*/
  GstObject        parent;

  GstGLContext    *context;

  /* input data */
  GstVideoInfo     in_info;
  GstVideoInfo     out_info;

  gboolean         initted;
  gboolean         passthrough;

  GstBuffer *    inbuf;
  GstBuffer *    outbuf;

  /* used for the conversion */
  GstGLFramebuffer *fbo;
  GstGLShader     *shader;

  /*< private >*/
  GstGLColorConvertPrivate *priv;

  gpointer _reserved[GST_PADDING];
};

/**
 * GstGLColorConvertClass:
 *
 * The #GstGLColorConvertClass struct only contains private data
 */
struct _GstGLColorConvertClass
{
  /*< private >*/
  GstObjectClass object_class;

  gpointer _padding[GST_PADDING];
};

/**
 * GST_GL_COLOR_CONVERT_EXT_FORMATS: (skip)
 *
 */
#if G_BYTE_ORDER == G_LITTLE_ENDIAN
#define GST_GL_COLOR_CONVERT_EXT_FORMATS \
    ", RGBA64_LE, BGR10A2_LE, RGB10A2_LE, BGR10x2_LE, RGB10x2_LE, P010_10LE, P012_LE, P016_LE, Y212_LE, Y412_LE" \
    ", A444_16LE, A422_16LE, A420_16LE, A444_12LE, A422_12LE, A420_12LE, A420_10LE" \
    ", A422_10LE, A444_10LE, I420_12LE, I420_10LE, I422_10LE, I422_12LE, Y444_16LE, Y444_12LE, Y444_10LE"
#else
#define GST_GL_COLOR_CONVERT_EXT_FORMATS \
    ", RGBA64_BE, P010_10BE, P012_BE, P016_BE, Y212_BE, Y412_BE" \
    ", A444_16BE, A422_16BE, A420_16BE, A444_12BE, A422_12BE, A420_12BE, A420_10BE" \
    ", A422_10BE, A444_10BE, I420_12BE, I420_10BE, I422_10BE, I422_12BE, Y444_10BE, Y444_12BE, Y444_16BE"
#endif

/**
 * GST_GL_COLOR_CONVERT_FORMATS:
 *
 * The currently supported formats that can be converted
 */
#define GST_GL_COLOR_CONVERT_FORMATS "{ RGBA, RGB, RGBx, BGR, BGRx, BGRA, xRGB, " \
                               "xBGR, ARGB, ABGR, GBRA, GBR, RGBP, BGRP, Y444, I420, YV12, Y42B, " \
                               "Y41B, NV12, NV21, NV16, NV61, NV24, YUY2, UYVY, Y210, AYUV, " \
                               "VUYA, Y410, A444, A422, GRAY8, GRAY16_LE, GRAY16_BE, " \
                               "RGB16, BGR16, ARGB64, A420, AV12, NV12_16L32S, NV12_4L4, RBGA, v210" \
                               GST_GL_COLOR_CONVERT_EXT_FORMATS "}"

/**
 * GST_GL_COLOR_CONVERT_VIDEO_CAPS:
 *
 * The currently supported #GstCaps that can be converted
 */
#define GST_GL_COLOR_CONVERT_VIDEO_CAPS \
    "video/x-raw(" GST_CAPS_FEATURE_MEMORY_GL_MEMORY "), "              \
    "format = (string) " GST_GL_COLOR_CONVERT_FORMATS ", "              \
    "width = " GST_VIDEO_SIZE_RANGE ", "                                \
    "height = " GST_VIDEO_SIZE_RANGE ", "                               \
    "framerate = " GST_VIDEO_FPS_RANGE ", "                             \
    "texture-target = (string) { 2D, rectangle, external-oes } "        \
    " ; "                                                               \
    "video/x-raw(" GST_CAPS_FEATURE_MEMORY_GL_MEMORY ","                \
    GST_CAPS_FEATURE_META_GST_VIDEO_OVERLAY_COMPOSITION "), "           \
    "format = (string) " GST_GL_COLOR_CONVERT_FORMATS ", "              \
    "width = " GST_VIDEO_SIZE_RANGE ", "                                \
    "height = " GST_VIDEO_SIZE_RANGE ", "                               \
    "framerate = " GST_VIDEO_FPS_RANGE ", "                             \
    "texture-target = (string) { 2D, rectangle, external-oes }"         \
    " ; "                                                               \
    GST_VIDEO_DMA_DRM_CAPS_MAKE                                         \
    " ; "                                                               \
    GST_VIDEO_CAPS_MAKE_WITH_FEATURES ("memory:DMABuf,"                 \
      GST_CAPS_FEATURE_META_GST_VIDEO_OVERLAY_COMPOSITION,              \
      "DMA_DRM")

GST_GL_API
GstGLColorConvert * gst_gl_color_convert_new (GstGLContext * context) G_GNUC_WARN_UNUSED_RESULT;

GST_GL_API
GstCaps *   gst_gl_color_convert_transform_caps (GstGLContext * context,
                                                 GstPadDirection direction,
                                                 GstCaps * caps,
                                                 GstCaps * filter);
GST_GL_API
GstCaps *   gst_gl_color_convert_fixate_caps    (GstGLContext * context,
                                                 GstPadDirection direction,
                                                 GstCaps * caps,
                                                 GstCaps * other);
GST_GL_API
gboolean    gst_gl_color_convert_set_caps    (GstGLColorConvert * convert,
                                              GstCaps           * in_caps,
                                              GstCaps           * out_caps);
GST_GL_API
gboolean    gst_gl_color_convert_decide_allocation (GstGLColorConvert   * convert,
                                                    GstQuery            * query);

GST_GL_API
GstBuffer * gst_gl_color_convert_perform    (GstGLColorConvert * convert, GstBuffer * inbuf) G_GNUC_WARN_UNUSED_RESULT;

GST_GL_API
gchar *     gst_gl_color_convert_swizzle_shader_string (GstGLContext * context);

GST_GL_API
gchar *     gst_gl_color_convert_yuv_to_rgb_shader_string (GstGLContext * context);

G_END_DECLS

#endif /* __GST_GL_COLOR_CONVERT_H__ */
