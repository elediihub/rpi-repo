/* GStreamer
 * Copyright (C) 2025 Seungha Yang <seungha@centricular.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 */

#pragma once

#include <gst/gst.h>
#include <gst/hip/hip-prelude.h>
#include <gst/hip/gsthip-enums.h>
#include <hip/hip_runtime.h>
#include <hip/hip_gl_interop.h>

G_BEGIN_DECLS

GST_HIP_API
hipError_t HipGLGetDevices (GstHipVendor vendor,
                            unsigned int* pHipDeviceCount,
                            int* pHipDevices,
                            unsigned int hipDeviceCount,
                            hipGLDeviceList deviceList);

GST_HIP_API
hipError_t HipGraphicsGLRegisterBuffer (GstHipVendor vendor,
                                        hipGraphicsResource** resource,
                                        unsigned int buffer,
                                        unsigned int flags);

G_END_DECLS

