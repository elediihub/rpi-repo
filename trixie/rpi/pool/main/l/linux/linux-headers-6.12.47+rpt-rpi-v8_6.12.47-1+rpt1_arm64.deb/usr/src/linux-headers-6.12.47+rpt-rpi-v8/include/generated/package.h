#define LINUX_PACKAGE_ID " Debian 1:6.12.47-1+rpt1"
