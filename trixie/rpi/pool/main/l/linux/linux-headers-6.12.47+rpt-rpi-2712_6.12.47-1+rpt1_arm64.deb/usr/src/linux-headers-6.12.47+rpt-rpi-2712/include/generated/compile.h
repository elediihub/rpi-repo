#define UTS_MACHINE		"aarch64"
#define LINUX_COMPILE_BY	"serge"
#define LINUX_COMPILE_HOST	"raspberrypi.com"
#define LINUX_COMPILER		"aarch64-linux-gnu-gcc-14 (Debian 14.2.0-19) 14.2.0, GNU ld (GNU Binutils for Debian) 2.44"
