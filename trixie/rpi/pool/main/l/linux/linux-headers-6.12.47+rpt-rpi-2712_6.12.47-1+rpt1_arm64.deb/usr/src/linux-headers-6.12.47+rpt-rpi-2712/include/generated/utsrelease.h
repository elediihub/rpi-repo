#define UTS_RELEASE "6.12.47+rpt-rpi-2712"
